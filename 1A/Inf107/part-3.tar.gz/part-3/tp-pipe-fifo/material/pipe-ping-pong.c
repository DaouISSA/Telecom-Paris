#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define n_ping 3

int main(int argc, char *argv[]) {
  /* Create two pipes ping and pong
   */

  int value = 7;
  int child = fork();
  if (child == 0) {
    /* Close the ends of the pipe that are not used by the child.
     */
    for (int i = 0; i < n_ping; i++) {
      /* Receive value from parent.
       */
      printf("%d recv ping %d\n", (int)getpid(), value);
      value = 2 * value + 1;
      /* Send value to parent.
       */
      printf("%d send pong %d\n", (int)getpid(), value);
    }
  } else {
    /* Close the ends of the pipe that are not used by the parent.
     */
    for (int i = 0; i < n_ping; i++) {
      printf("%d send ping %d\n", (int)getpid(), value);
      printf("%d recv pong %d\n", (int)getpid(), value);
      value = 2 * value + 1;
    }
  }
}
