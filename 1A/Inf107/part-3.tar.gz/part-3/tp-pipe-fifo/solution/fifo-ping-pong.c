#include <assert.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define n_ping 3

void print_usage(char *executable, char *msg) {
  printf("Error : %s\n", msg);
  printf("Usage : %s [ping|pong]\n", executable);
  exit(1);
}

int main(int argc, char *argv[]) {

  int rv;

  if (argc != 2)
    print_usage(argv[0], "wrong parameters");

  int is_ping = 0; /* True when process is ping */
  if (strcmp(argv[1], "ping") == 0)
    is_ping = 1;

    /* Create a fifo ping/pong if process is ping/pong
     */
#ifdef TEACHER
  if (is_ping) {
    rv = mkfifo("ping", 0644);
    rv = mkfifo("pong", 0644);
  }
#endif

  int value = 7;
  int ping = -1;
  int pong = -1;
  /* Open the fifo ping/pong if process is ping/pong.
   */
#ifdef TEACHER
  if (is_ping) {
    ping = open("ping", O_WRONLY);
    assert(0 <= ping);
    pong = open("pong", O_RDONLY);
    assert(0 <= pong);

  } else {
    ping = open("ping", O_RDONLY);
    assert(0 <= ping);
    pong = open("pong", O_WRONLY);
    assert(0 <= pong);
  }
#endif

  if (is_ping) {
    for (int i = 0; i < n_ping; i++) {
#ifdef TEACHER
      rv = write(ping, &value, sizeof(value));
      assert(rv == sizeof(value));
#endif
      printf("%d send to pong %d\n", (int)getpid(), value);
#ifdef TEACHER
      rv = read(pong, &value, sizeof(value));
      assert(rv == sizeof(value));
#endif
      printf("%d recv from pong %d\n", (int)getpid(), value);
      value = 2 * value + 1;
    }
  } else {
    for (int i = 0; i < n_ping; i++) {
      /* Receive value from process ping.
       */
#ifdef TEACHER
      rv = read(ping, &value, sizeof(value));
      assert(rv == sizeof(value));
#endif
      printf("%d recv from ping %d\n", (int)getpid(), value);
      value = 2 * value + 1;
      /* Send value to parent.
       */
#ifdef TEACHER
      rv = write(pong, &value, sizeof(value));
      assert(rv == sizeof(value));
#endif
      printf("%d send to ping %d\n", (int)getpid(), value);
    }
  }
}