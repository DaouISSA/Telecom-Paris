#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define n_ping 3

int main(int argc, char *argv[]) {
  /* Create two pipes ping and pong
   */
#ifdef TEACHER
  int ping[2];
  int pong[2];

  int rv;
  rv = pipe(ping);
  assert(rv == 0);
  rv = pipe(pong);
  assert(rv == 0);
#endif

  int value = 7;
  int child = fork();
  if (child == 0) {
    /* Close the ends of the pipe that are not used by the child.
     */
#ifdef TEACHER
    close(ping[1]);
    close(pong[0]);
#endif
    for (int i = 0; i < n_ping; i++) {
      /* Receive value from parent.
       */
#ifdef TEACHER
      rv = read(ping[0], &value, sizeof(value));
      assert(rv == sizeof(value));
#endif
      printf("%d recv ping %d\n", (int)getpid(), value);
      value = 2 * value + 1;
      /* Send value to parent.
       */
#ifdef TEACHER
      rv = write(pong[1], &value, sizeof(value));
      assert(rv == sizeof(value));
#endif
      printf("%d send pong %d\n", (int)getpid(), value);
    }
  } else {
    /* Close the ends of the pipe that are not used by the parent.
     */
#ifdef TEACHER
    close(ping[0]);
    close(pong[1]);
#endif
    for (int i = 0; i < n_ping; i++) {
#ifdef TEACHER
      rv = write(ping[1], &value, sizeof(value));
      assert(rv == sizeof(value));
#endif
      printf("%d send ping %d\n", (int)getpid(), value);
#ifdef TEACHER
      rv = read(pong[0], &value, sizeof(value));
      assert(rv == sizeof(value));
#endif
      printf("%d recv pong %d\n", (int)getpid(), value);
      value = 2 * value + 1;
    }
  }
}
