#include <assert.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
  if (argc != 2) {
    printf("Usage : %s <file-to-dump>>\n", argv[0]);
    exit(1);
  }

  /* Open file to read it. Check the returned value.
   */

  uint8_t value;
  int nbyte;
  int offset = 0;

  /* For each iteration, print the file offset. Then, read and print 4 uint8_t
   * values (unsigned integers of 8 bits).
   */
  while (1) {
    /* Read an uint8_t integer. Check the returned value is correct.
     */

    /* Exit when we reach end of file or cannot read a value.
     */
    if (nbyte != sizeof(value)) {
      printf("\n");
      break;
    }

    if (offset % 4 == 0) {
      /* Start a new line.
       */
      printf("\n");
      /* Print the file offset.
       */
      printf("%08x :", offset);
    }
    printf(" %02x", value);
    offset = offset + sizeof(value);
  }

  /* Close file before terminating. Done by default.
   */
}
